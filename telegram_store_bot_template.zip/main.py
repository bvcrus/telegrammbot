from aiogram import Bot, Dispatcher, executor, types
import os
from dotenv import load_dotenv

# Загрузка токенов из .env
load_dotenv()
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")

bot = Bot(token=TELEGRAM_TOKEN)
dp = Dispatcher(bot)

# Тарифы и их соответствующие файлы с ключами
TARIFFS = {
    "1 месяц": "keys_1m.txt",
    "2 месяца": "keys_2m.txt",
    "3 месяца": "keys_3m.txt",
    "4 месяца": "keys_4m.txt",
    "5 месяцев": "keys_5m.txt",
    "7 месяцев": "keys_7m.txt",
    "10 месяцев": "keys_10m.txt",
    "13 месяцев": "keys_13m.txt"
}

@dp.message_handler(commands=["start"])
async def start(message: types.Message):
    buttons = [types.KeyboardButton(t) for t in TARIFFS.keys()]
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True).add(*buttons)
    await message.answer("Выберите нужный срок подписки:", reply_markup=keyboard)

@dp.message_handler(lambda message: message.text in TARIFFS)
async def choose_tariff(message: types.Message):
    tariff = message.text
    await message.answer(
        f"Вы выбрали: {tariff}\n\n💰 Выберите способ оплаты:",
        reply_markup=payment_buttons(tariff)
    )

def payment_buttons(tariff):
    markup = types.InlineKeyboardMarkup()
    markup.add(
        types.InlineKeyboardButton(text="🪙 Оплатить криптой", callback_data=f"pay_crypto:{tariff}"),
        types.InlineKeyboardButton(text="🏦 Оплатить по СБП", callback_data=f"pay_lava:{tariff}")
    )
    return markup

@dp.callback_query_handler(lambda c: c.data.startswith("pay_"))
async def process_payment(callback: types.CallbackQuery):
    method, tariff = callback.data.split(":")
    if method == "pay_crypto":
        await callback.message.answer(f"🔗 Ваша ссылка на оплату криптой за {tariff}:\n[ТЕСТОВАЯ ССЫЛКА]")
    elif method == "pay_lava":
        await callback.message.answer(f"🔗 Ваша ссылка на оплату по СБП за {tariff}:\n[ТЕСТОВАЯ ССЫЛКА]")
    await callback.answer()

async def issue_key(tariff: str, user_id: int):
    file_path = TARIFFS[tariff]
    if not os.path.exists(file_path):
        return await bot.send_message(user_id, "❌ Нет доступных ключей.")
    with open(file_path, "r") as f:
        lines = f.readlines()
    if not lines:
        return await bot.send_message(user_id, "❌ Ключи закончились.")
    key = lines[0].strip()
    with open(file_path, "w") as f:
        f.writelines(lines[1:])
    await bot.send_message(user_id, f"✅ Ваш ключ: {key}")

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
